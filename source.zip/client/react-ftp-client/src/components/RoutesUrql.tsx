import * as React from "react";

function RoutesUrql() {
  return <>ddd</>;
}

export default RoutesUrql;
