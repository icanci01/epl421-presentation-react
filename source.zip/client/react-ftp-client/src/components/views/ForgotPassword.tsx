import { Box } from "@chakra-ui/react";

function ForgotPassword() {
  return (
    <Box h="100vh" bg="blue.400">
      <>
      TO BE ADDED LATER
      </>
    </Box>
  );
}

export default ForgotPassword;