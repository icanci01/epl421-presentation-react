function greeter(firstName, lastName) {
    return "Hello " + firstName + " " + lastName;
}

var firstName = "John";
var lastName = "Doe";

console.log(greeter(firstName, lastName));