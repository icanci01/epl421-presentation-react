function greeter(firstName: string, lastName: string) {
    return "Hello, " + firstName + " " + lastName;
}

let firstName: string = "Jane";
let lastName: string = "Doe";

console.log(greeter(firstName, lastName));